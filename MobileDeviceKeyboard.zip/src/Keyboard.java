import java.util.Scanner;
import java.util.ArrayList;

public class Keyboard { //main driver of the program
	public static void main(String[] args) {
		Scanner inData = new Scanner(System.in);
		ArrayList<String> sentences = new ArrayList<String>();
		String input = "";
		//prompt user the options
		System.out.print("Enter 1 to train, 2 to input, 3 to display, 0 to exit: ");
		try {
			input = inData.next();
			inData.nextLine();
			AutocompleteProvider keyboard = new AutocompleteProvider();
			//while user wants to continue program
			while (!input.equals("0")) {
				//if user wants to train the keyboard
				if (input.equals("1")) {
					String passage = "";
					System.out.print("Train: ");
					passage = inData.nextLine();
					sentences.add(passage);
					//train input
					keyboard.train(passage);
				}
				//if user wants to get autocomplete suggestions
				else if (input.equals("2")) {
					ArrayList<Candidate> provider = new ArrayList<Candidate>();
					String fragment = "";
					System.out.print("Input: ");
					fragment = inData.next();
					fragment = fragment.toLowerCase();
					//find words based on input
					provider = keyboard.findWords(fragment);
					//if there are no matching words
					if (provider.isEmpty()) {
						System.out.println("No words trained to match the fragment.");
					}
					//if there are matching words
					else {
						System.out.print("\"" + fragment + "\" --> ");
						keyboard.print(provider);
					}
				}
				//if user wants to display all trained sentences
				else if (input.equals("3")) {
					if (sentences.size() == 0) {
						System.out.println("No sentences trained yet.");
					}
					else {
						for (int i = 0; i < sentences.size(); i++) {
							System.out.println(sentences.get(i));
						}
					}
				}
				//prompt user the options
				System.out.print("Enter 1 to train, 2 to input, 3 to display all, 0 to exit: ");
				input = inData.next();
				inData.nextLine();
			}
		} catch (Exception e){
			
		}
	}
}