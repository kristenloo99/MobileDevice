public class Candidate { //class for each learned word
	private String m_word = ""; //stores the word
	private int m_confidence = 1; //stores the confidence level
	public void setWord(String word) { //setter for word
		m_word = word;
	}
	public void incrementConfidence() { //increment confidence level
		m_confidence += 1;
	}
	public String getWord() { //getter for word
		return m_word;
	}
	public int getConfidence() { //getter for confidence level
		return m_confidence;
	}
}
