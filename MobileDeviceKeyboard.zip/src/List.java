import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class List { //class for list in keyboard
	private Node m_head = null; //head of linked list
	private int m_max = 1; //stores max confidence level
	class Node {
		Map<String, Node> m_data = new HashMap<String, Node>(); //stores the letter and Node for the next letter 
		Candidate m_word = new Candidate(); //stores the word
	};
	public void add(String word) { //add word to list
		//if list is empty
		if (m_head == null) {
			Node curr = new Node();
			m_head = curr;
		}
		Node curr = m_head;
		Node prev = m_head;
		boolean newWord = false;
		//add each letter to list
		for (int i = 0; i < word.length(); i++) {
			prev = curr;
			String letter = word.substring(i, i + 1);
			if (curr.m_data == null) {
				curr.m_data = new HashMap<String, Node>();
			}
			//if letter was added to path already
			if ((curr.m_data).containsKey(letter)) {
				curr = (curr.m_data).get(letter);
			}
			//if letter was not added to path yet
			else {
				newWord = true;
				curr = new Node();
				prev.m_data.put(letter, curr);
			}
		}
		//if not a repeated word
		if (newWord) {
			curr.m_data = null;
			curr.m_word.setWord(word);
		}
		//if a repeated word
		else {
			curr.m_word.incrementConfidence();
			if (curr.m_word.getConfidence() > m_max) {
				setMax(curr.m_word.getConfidence());
			}
		}
	}
	public ArrayList<Candidate> find(String fragment) { //returns a list of words containing the beginning fragment
		int i = 0;
		Node curr = m_head;
		Node prev;
		boolean word = false;
		//iterate to position of fragment in list
		while (i < fragment.length() && curr != null && curr.m_data != null) {
			word = true;
			prev = curr;
			String letter = fragment.substring(i, i + 1);
			curr = (curr.m_data).get(letter);
			i += 1;
		}
		ArrayList<Candidate> found = new ArrayList<Candidate>();
		//if reached the end of the word
		if (curr != null && i == fragment.length()) {
			if (curr.m_word.getWord() != "") {
				found.add(curr.m_word);
			}
			recurse(curr, found);
		}
		return found;
	}
	public Candidate recurse(Node curr, ArrayList<Candidate> found) { //add each word after curr to found
		//base case
		if (curr.m_data == null) {
			return curr.m_word;
		}
		Iterator<Map.Entry<String, Node>> it = curr.m_data.entrySet().iterator();
		//recursive case
		while (it.hasNext()) {
			Map.Entry<String, Node> entry = it.next();
			Candidate word = recurse(entry.getValue(), found);
			//if reached the end of a word
			if (word.getWord() != "") {
				found.add(word);
			}
		}
		return  curr.m_word;
	}
	public int getMax() { //getter for max
		return m_max;
	}
	public void setMax(int max) { //setter for max
		m_max = max;
	}
	public ArrayList<Candidate> dump() { //debug
		ArrayList<Candidate> found = new ArrayList<Candidate>();
		recurse(m_head, found);
		return found;
	}
}
