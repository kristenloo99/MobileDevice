import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class AutocompleteProvider { //class for keyboard
	List m_keyboard; //linked list keyboard
	public AutocompleteProvider() { //constructor
		m_keyboard = new List();
	}
	public ArrayList<Candidate> findWords(String fragment) { //finds words beginning with fragment in keyboard
		ArrayList<Candidate> found = new ArrayList<Candidate>();
		found = m_keyboard.find(fragment);
		return found;
	}
	public void train(String passage) { //trains the algorithm with the provided passage
		String word = "";
		//iterate through passage and train each word
		for (int i = 0; i < passage.length(); i++) {
			if (!passage.substring(i, i + 1).equals(" ") && !passage.substring(i, i + 1).equals(".") && !passage.substring(i, i + 1).equals("\t") && !passage.substring(i, i + 1).equals(",")) {
				word += passage.substring(i, i + 1);
			}
			//add word to keyboard
			else {
				word = word.toLowerCase();
				m_keyboard.add(word);
				word = "";
			}
		}
		word = word.toLowerCase();
		m_keyboard.add(word);
	}
	public void print(ArrayList<Candidate> provider) { //print the words in the provider for autocomplete suggestions
		int count = m_keyboard.getMax();
		int keep = 0;
		int i = 0;
		boolean atEnd = false;
		//iterate through provider and print from highest to lowest confidence
		while (i < provider.size() && count > 0) {
			if (provider.get(i).getConfidence() == count) {
				System.out.print("\"" + provider.get(i).getWord() + "\" (" + provider.get(i).getConfidence() + ")");
				if (provider.size() != 1) {
					System.out.print(", ");
				}
				if (i == provider.size() - 1) {
					atEnd = true;
				}
				provider.remove(i);
			}
			else {
				if (i == provider.size() - 1) {
					atEnd = true;
				}
				i++;
			}
			if (provider.size() != 0 && atEnd) {
				atEnd = false;
				count--;
				i = 0;
			}
		}
		System.out.println();
	}
	public void dump() { //debug
		ArrayList<Candidate> found = new ArrayList<Candidate>();
		found = m_keyboard.dump();
		print(found);
	}
}
